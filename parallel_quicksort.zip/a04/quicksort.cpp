/*
Name: Dustin Meckley
Course: ciss433 
Date: 11/11/2016
File: quicksort.cpp
*/


// preprocessor_directives:
#include <iostream>
#include <list>
#include <algorithm>
#include <future>
#include <iomanip>


// typedef_global_declaration:
typedef std::chrono::milliseconds ms;


// sequential_quick_sort:
template<typename T>
std::list<T> sequential_quick_sort(std::list<T> input) 
{
	if(input.empty())
		return input;

	std::list<T> result;
	/* 
	void splice(iterator pos, list& x, iterator i);

	Transfers only the element pointed by i from x into the container.
	
	This effectively inserts those elements into the container and removes them from x, 
	altering the sizes of both containers. The operation does not involve the construction 
	or destruction of any element. They are transferred, no matter whether x is an lvalue or an rvalue, 
	or whether the value_type supports move-construction or not.
	*/
	result.splice(result.begin(), input, input.begin());
	T const& pivot = *result.begin();

	/*
	template <class BidirectionalIterator, class UnaryPredicate>
  		BidirectionalIterator partition (BidirectionalIterator first,
                                   		 BidirectionalIterator last, UnaryPredicate pred);

    Rearranges the elements from the range [first,last), in such a way that all the elements for which pred 
    returns true precede all those for which it returns false. The iterator returned points to the first 
    element of the second group.
    */
	auto divide_point = std::partition(input.begin(), input.end(), 
		[&](T const& t){return t < pivot;});

	std::list<T> lower_part;
	/* 
	void splice (iterator position, list& x, iterator first, iterator last);

	Transfers the range [first,last) from x into the container.
	
	This effectively inserts those elements into the container and removes them from x, 
	altering the sizes of both containers. The operation does not involve the construction 
	or destruction of any element. They are transferred, no matter whether x is an lvalue or an rvalue, 
	or whether the value_type supports move-construction or not.
	*/
	lower_part.splice(lower_part.end(), input, input.begin(), divide_point);

	auto new_lower(sequential_quick_sort(std::move(lower_part)));
	auto new_higher(sequential_quick_sort(std::move(input)));

	/* 
	void splice (iterator position, list& x);

	Transfers all the elements of x into the container.
	
	This effectively inserts those elements into the container and removes them from x, 
	altering the sizes of both containers. The operation does not involve the construction 
	or destruction of any element. They are transferred, no matter whether x is an lvalue or an rvalue, 
	or whether the value_type supports move-construction or not.
	*/
	result.splice(result.end(), new_higher);
	result.splice(result.begin(), new_lower);

	return result;
}


// parallel_quick_sort:
template<typename T>
std::list<T> parallel_quick_sort(std::list<T> input) 
{
	if(input.empty())
		return input;

	std::list<T> result;
	/* 
	void splice(iterator pos, list& x, iterator i);

	Transfers only the element pointed by i from x into the container.
	
	This effectively inserts those elements into the container and removes them from x, 
	altering the sizes of both containers. The operation does not involve the construction 
	or destruction of any element. They are transferred, no matter whether x is an lvalue or an rvalue, 
	or whether the value_type supports move-construction or not.
	*/
	result.splice(result.begin(), input, input.begin());
	T const& pivot = *result.begin();

	/*
	template <class BidirectionalIterator, class UnaryPredicate>
  		BidirectionalIterator partition (BidirectionalIterator first,
                                   		 BidirectionalIterator last, UnaryPredicate pred);

    Rearranges the elements from the range [first,last), in such a way that all the elements for which pred 
    returns true precede all those for which it returns false. The iterator returned points to the first 
    element of the second group.
    */
	auto divide_point = std::partition(input.begin(), input.end(), 
		[&](T const& t){return t < pivot;});

	std::list<T> lower_part;
	/* 
	void splice (iterator position, list& x, iterator first, iterator last);

	Transfers the range [first,last) from x into the container.
	
	This effectively inserts those elements into the container and removes them from x, 
	altering the sizes of both containers. The operation does not involve the construction 
	or destruction of any element. They are transferred, no matter whether x is an lvalue or an rvalue, 
	or whether the value_type supports move-construction or not.
	*/
	lower_part.splice(lower_part.end(), input, input.begin(), divide_point);

	/*
	std::future<>:
	--------------
	template <class T>  future;
	template <class R&> future<R&>;     
	template <>         future<void>;   

	A future is an object that can retrieve a value from some provider object or function, 
	properly synchronizing this access if in different threads.

	Calling future::get on a valid future blocks the thread until the provider makes the 
	shared state ready (either by setting a value or an exception to it). This way, two threads 
	can be synchronized by one waiting for the other to set a value.

	The lifetime of the shared state lasts at least until the last object with which it is associated 
	releases it or is destroyed. Therefore, if associated to a future, the shared state can survive the 
	object from which it was obtained in the first place (if any).

	std::async():
	-------------
	template <class Fn, class... Args>
  		future<typename result_of<Fn(Args...)>::type>
    		async (Fn&& fn, Args&&... args);

    Call function asynchronously.
	Calls fn (with args as arguments) at some point, returning without waiting for the execution of fn to complete.

	The value returned by fn can be accessed through the future object returned (by calling its member future::get).

	The second version (2) lets the caller select a specific launching policy, while the first version (1) uses 
	automatic selection, as if calling (2) with launch::async|launch::deferred as policy.

	The function temporarily stores in the shared state either the threading handler used or decay copies of fn 
	and args (as a deferred function) without making it ready. Once the execution of fn is completed, the shared 
	state contains the value returned by fn and is made ready.
	*/
	std::future< std::list<T> > new_lower(std::async(&parallel_quick_sort<T>,std::move(lower_part)));
	auto new_higher(parallel_quick_sort(std::move(input)));

	/* 
	void splice (iterator position, list& x);

	Transfers all the elements of x into the container.
	
	This effectively inserts those elements into the container and removes them from x, 
	altering the sizes of both containers. The operation does not involve the construction 
	or destruction of any element. They are transferred, no matter whether x is an lvalue or an rvalue, 
	or whether the value_type supports move-construction or not.
	*/
	result.splice(result.end(), new_higher);
	result.splice(result.begin(), new_lower.get());

	return result;
}


int main(int argc, char *argv[])
{
	// local_variable_declaration:
	int n;

	// commandline_input:
	if(argc != 2)
	{
		std::cout << "Usage: "<< argv[0] << " <number> " << std::endl;
		exit(0);
	}
	else
	{
		std::stringstream convert(argv[1]); 	// convert char * to int.
		if(!(convert >> n)) 
			n = 0; 
	}

	// random_number_generation:
	std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> num(1, 100);

	// sequential_quick_sort & parallel_quick_sort lists:
	std::list<int> rand_num_gen_list;
	for (int i = 0; i < n; ++i)
		rand_num_gen_list.push_back(num(gen));
	std::list<int> sequential_list = rand_num_gen_list;		// Copy into sequential_list.
	std::list<int> parallel_list = rand_num_gen_list;		// Copy into parallel_list.

	// sequential_quick_sort:
	auto sequential_start = std::chrono::high_resolution_clock::now();						// start timer.
	std::list<int> sequential_quick_sort_result = sequential_quick_sort(sequential_list);	// sort.
	auto sequential_end = std::chrono::high_resolution_clock::now();						// stop timer.

  	// sequential_quick_sort_time:
  	ms sequential_quick_sort_time = std::chrono::duration_cast<ms>(sequential_end - sequential_start);					// integer conversion.
  	std::chrono::duration<double, std::milli> sequential_quick_sort_time_double = (sequential_end - sequential_start);	// double conversion.
    std::cout << "Sorting " << n << " random numbers with a sequential quicksort took " << 
    	sequential_quick_sort_time.count() << " ms." << std::endl;

	// parallel_quick_sort:
	auto parallel_start = std::chrono::high_resolution_clock::now();					// start timer.
	std::list<int> parallel_quick_sort_result = parallel_quick_sort(parallel_list);		// sort.
	auto parallel_end = std::chrono::high_resolution_clock::now();						// stop timer.

  	// parallel_quick_sort_time:
  	ms parallel_quick_sort_time = std::chrono::duration_cast<ms>(parallel_end - parallel_start);					// integer conversion.
  	std::chrono::duration<double, std::milli> parallel_quick_sort_time_double = (parallel_end - parallel_start);	// double conversion.
    std::cout << "Sorting " << n << " random numbers with a parallel quicksort took " << 
    	parallel_quick_sort_time.count() << " ms." << std::endl;

    // speed_up_ratio:
	auto shorter_duration = parallel_quick_sort_time_double;
	auto longer_duration = sequential_quick_sort_time_double;
    auto speed_up = longer_duration / shorter_duration;
	if(sequential_quick_sort_time < parallel_quick_sort_time)	
	{
		// sequential_quick_sort is faster.
		shorter_duration = sequential_quick_sort_time_double;
		longer_duration = parallel_quick_sort_time_double;
		speed_up = longer_duration / shorter_duration;
		std::cout << "Sequential was " << std::fixed << std::setprecision(2) << speed_up << "x faster than parallel." << std::endl;

	}
	else	
	{
		// parallel_quick_sort is faster.
		std::cout << "Parallel was " << std::fixed << std::setprecision(2) << speed_up << "x faster than sequential." << std::endl;
	}

  	// return_0_to_OS:
	return 0;
}
